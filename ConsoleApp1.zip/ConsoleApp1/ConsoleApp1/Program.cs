﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            #region Read numbers from COnsole and sum
            //unsigned - işarəsiz
            //Console.Write("How many numbers would You want to sum: ");
            //int countOfNumbers = int.Parse(Console.ReadLine());

            //int[] numbers = new int[countOfNumbers];
            //int total = 0;

            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    Console.Write($"Please, input {i+1}th number: ");
            //    int number = int.Parse(Console.ReadLine());
            //    numbers[i] = number;
            //    total += number;
            //}

            //Console.WriteLine($"The sum of your inputted numbers: {total}");

            //string result = 5 > 4 ? "Salam" : "Sag ol"; //ternary operator
            #endregion

            Console.WriteLine(ConcatWords("Samir", "Zakir", "Aqil", "Qedim", "Vahid", "Nadir"));
            Console.ReadKey();
        }

        #region Method overloading
        //static string ConcatWords(string w1, string w2)
        //{
        //    return w1 + " " + w2;
        //}

        //static bool ConcatWords(string a, bool b)
        //{
        //    return true;
        //}

        //static string ConcatWords(string w1, string w2, string w3)
        //{
        //    return w1 + " " + w2 + " " + w3;
        //}

        //static string ConcatWords(string w1, string w2, string w3, string w4)
        //{
        //    return w1 + " " + w2 + " " + w3 + " " + w4;
        //}


        static void Add(byte a)
        {
            Console.WriteLine(a);
        }

        static void Add(int a)
        {
            Console.WriteLine(a);
        }

        #endregion

        static string ConcatWords(params string[] words)
        {
            string result = "";

            for (int i = 0; i < words.Length; i++)
            {
                result += words[i] + (i != words.Length - 1 ? " - " : "");

                //if (i != words.Length - 1)
                //{
                //    result += " - ";
                //}
            }

            return result;
        }

        #region Secondary methods
        static string AppendHi(string input)
        {
            return "Salam " + input + " sag ol";
        }

        static string SumAndWrite(int a, int b)
        {
            return (a + b).ToString();
        }

        static bool IsOlder(int n) => n > 18;
        #endregion

    }
}
