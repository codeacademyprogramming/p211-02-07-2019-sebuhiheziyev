﻿using System;

namespace projects02._07._2019
{
    class Program
    {
        static void Main(string[] args)
        {

            #region homWork1
            //Console.Write("Nece dene e poct daxil edesdiniz?  ");

            //int countEmail = int.Parse(Console.ReadLine());
            //int[] numbers = new int[countEmail];
            //string[] validEmail = new string[countEmail];
            //string[] validEmailArrey = new string[countEmail];
            //string list = " ";
            //bool falseEmail = false;
            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    Console.Write($"{i + 1}Emaili Daxil edin: ");
            //    string emailName = Console.ReadLine();
            //    validEmail[i] = emailName;

            //    if (emailName.IndexOf("@") != -1)
            //    {
            //        validEmailArrey[i] = emailName;
            //        list = list + " " + validEmailArrey[i];
            //        falseEmail = true;
            //    }
            //    else
            //    {

            //    }
            //}

            //if (falseEmail == false)
            //{
            //    Console.WriteLine("Hec bir duzgun email yoxdu");
            //}
            //else
            //{
            //    Console.WriteLine("Duzgun Email Unvanlari: " + list);

            //}

            #endregion

            #region homWork2

            Console.Write("Nece dene eded daxil edesdiniz?  ");

            int countEmail = int.Parse(Console.ReadLine());
            int[] numbers = new int[countEmail];
            int s = 0;
            int k = 0;
            bool answer = false;
            
          
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write($"{i + 1}-ci Ededi Daxil edin: ");
                int numRead = int.Parse(Console.ReadLine());
                if(numRead > 18)
                {
                    s += numRead;
                    k++;
                    answer = true;
                }
                else
                {
                   
                }

            }

            if(answer == false)
            {
                Console.WriteLine("Daxil Etdiyiniz edelerden hec biri 18 den boyuk deyil");

            }
            else
            {
            Console.WriteLine("Daxil Etdiyniz ededlerin  " +k + "  denesi 18den boyukdur ve onlarin ededi ortasi  " + s/k + "  dir" );

            }




            #endregion

        }
    }
}
